import { PrismaClient } from '@prisma/client';
import * as bcrypt from 'bcryptjs';
import * as fs from 'fs';
import * as path from 'path';
import { translateInstructions } from '../src/modules/workouts/data/exercise-translations';

const prisma = new PrismaClient();

async function main() {
  console.log('Seeding Super Admin user...');
  const adminEmail = 'robersonsouza@outlook.com';
  const existingAdmin = await prisma.user.findUnique({ where: { email: adminEmail } });
  
  if (!existingAdmin) {
    const hashedPassword = await bcrypt.hash('Mudar123!', 10);
    await prisma.user.create({
      data: {
        email: adminEmail,
        name: 'Roberson Souza (Super Admin)',
        passwordHash: hashedPassword,
        role: 'ADMIN',
        isActive: true,
        authProvider: 'LOCAL',
      },
    });
    console.log(`Super Admin user created: ${adminEmail}`);
  } else {
    // Ensure Super Admin has ADMIN role and is active
    await prisma.user.update({
      where: { id: existingAdmin.id },
      data: {
        role: 'ADMIN',
        isActive: true,
      },
    });
    console.log(`Super Admin user verified/updated: ${adminEmail}`);
  }

  console.log('Seeding specialized AI agents...');
  
  const agentsData = [
    {
      name: 'Dra. Maya — Saúde & Longevidade',
      description: 'Especialista em saúde física, sono e longevidade.',
      systemPrompt: 'Seu nome é Dra. Maya. Você é a ESPECIALISTA EM SAÚDE FÍSICA, SONO E LONGEVIDADE da plataforma Vita Saúde. Sua função é analisar indicadores biológicos (sono, biometria, batimentos, sintomas), orientar sobre rotinas saudáveis e prevenir estresse metabólico.',
      modelName: 'gpt-4o-mini',
      temperature: 0.7,
      isDefault: false
    },
    {
      name: 'Nutri Bia — Nutrição & Macros',
      description: 'Especialista nutricional e visão computacional.',
      systemPrompt: 'Seu nome é Nutri Bia. Você é a ESPECIALISTA NUTRICIONAL E VISÃO COMPUTACIONAL da plataforma Vita Saúde. Sua função é analisar fotos de refeições enviadas pelo usuário, extrair calorias/macronutrientes da Tabela TACO e sugerir ajustes na dieta.',
      modelName: 'gpt-4o-mini',
      temperature: 0.6,
      isDefault: false
    },
    {
      name: 'Coach Iron — Personal Trainer & Musculação',
      description: 'Especialista em musculação, hipertrofia, força, periodização e sobrecarga progressiva.',
      systemPrompt: 'Seu nome é Coach Iron. Você é o PERSONAL TRAINER E PREPARADOR FÍSICO VIRTUAL da plataforma Vita Saúde. Sua função é criar treinos personalizados baseados nos objetivos do usuário (hipertrofia, força, definição, resistência), calcular progressão de carga, gerenciar volume de treinos por grupo muscular e orientar sobre a execução dos exercícios.',
      modelName: 'gpt-4o-mini',
      temperature: 0.6,
      isDefault: false
    },
    {
      name: 'Vita — Orquestradora Geral',
      description: 'Orquestradora principal de saúde, treinos e longevidade.',
      systemPrompt: 'Seu nome é Vita. Você é a ORQUESTRADORA PRINCIPAL DE SAÚDE & LONGEVIDADE da plataforma Vita Saúde. Sua função é correlacionar os pilares de treino, nutrição, sono, hidratação, exames laboratoriais e bioimpedância, fornecendo diagnósticos executivos integrados e planos de ação para a longevidade do usuário.',
      modelName: 'gpt-4o-mini',
      temperature: 0.7,
      isDefault: true
    }
  ];

  const agentMap: Record<string, string> = {};

  for (const ag of agentsData) {
    const existing = await prisma.agent.findFirst({ where: { name: ag.name } });
    if (!existing) {
      const created = await prisma.agent.create({ data: ag });
      agentMap[ag.name] = created.id;
      console.log(`Agent created: ${ag.name}`);
    } else {
      agentMap[ag.name] = existing.id;
    }
  }

  console.log('Seeding real RAG Knowledge Documents...');
  const filesToSeed = [
    {
      fileName: 'Tabela_TACO_Composicao_Alimentos_Brasileira.txt',
      title: 'Tabela TACO — Composição de Alimentos Brasileira.pdf',
      agentName: 'Nutri Bia — Nutrição & Macros',
      fileType: 'PDF',
      chunks: 142
    },
    {
      fileName: 'Guia_Treino_Hipertrofia_Longevidade.txt',
      title: 'Guia de Treino de Hipertrofia e Longevidade.pdf',
      agentName: 'Dra. Maya — Saúde & Longevidade',
      fileType: 'PDF',
      chunks: 38
    },
    {
      fileName: 'Planejamento_Orcamentario_Metas_2026.txt',
      title: 'Planejamento Orçamentário e Metas 2026.txt',
      agentName: 'Otávio — Estrategista Financeiro',
      fileType: 'TXT',
      chunks: 12
    }
  ];

  const kbDir = path.join(__dirname, '../../../knowledge_base_files');

  for (const f of filesToSeed) {
    const filePath = path.join(kbDir, f.fileName);
    if (fs.existsSync(filePath)) {
      const content = fs.readFileSync(filePath, 'utf-8');
      const agentId = agentMap[f.agentName] || agentMap['Vita — Orquestradora Geral'];

      const existingDoc = await prisma.knowledgeDocument.findFirst({ where: { title: f.title } });
      if (!existingDoc) {
        const doc = await prisma.knowledgeDocument.create({
          data: {
            agentId,
            title: f.title,
            fileType: f.fileType,
            totalChunks: f.chunks,
          }
        });

        // Seed initial text chunks
        await prisma.knowledgeChunk.create({
          data: {
            documentId: doc.id,
            content: content.slice(0, 1000),
            chunkIndex: 0,
          }
        });
        console.log(`Document indexed: ${f.title}`);
      }
    }
  }

  console.log('Seeding 1,323 3D exercises with animated GIFs from ExerciseGymGifsDB CDN...');
  const cdnBaseUrl = 'https://cdn.jsdelivr.net/gh/JahelCuadrado/ExerciseGymGifsDB@v1.1.0';
  const muscleFolders = [
    'pectorals', 'lats', 'delts', 'biceps', 'triceps', 'quads', 'hamstrings',
    'abs', 'glutes', 'calves', 'forearms', 'traps', 'upper-back', 'abductors',
    'adductors', 'cardio', 'levator-scapulae', 'serratus-anterior', 'spine',
  ];

  const muscleGroupMap: Record<string, string> = {
    pectorals: 'PEITORAL', lats: 'DORSAL', delts: 'OMBRO', biceps: 'BICEPS',
    triceps: 'TRICEPS', quads: 'QUADRICEPS', hamstrings: 'POSTERIOR_COXA',
    abs: 'ABDOMEN', glutes: 'GLUTEOS', calves: 'PANTURRILHA', forearms: 'ANTEBRACO',
    traps: 'TRAPEZIO', 'upper-back': 'DORSAL', abductors: 'GLUTEOS', adductors: 'COXA',
    cardio: 'CARDIO', 'levator-scapulae': 'TRAPEZIO', 'serratus-anterior': 'ABDOMEN', spine: 'LOMBAR',
  };

  const namePtMap: Record<string, string> = {
    'barbell bench press': 'Supino Reto com Barra',
    'dumbbell incline bench press': 'Supino Inclinado com Halteres',
    'push-up': 'Flexão de Braço',
    'cable pulldown': 'Puxada Frontal no Cabo',
    'pull-up': 'Barra Fixa Pronada',
    'barbell standing wide military press': 'Desenvolvimento Militar com Barra',
    'dumbbell lateral raise': 'Elevação Lateral com Halteres',
    'barbell curl': 'Rosca Direta com Barra',
    'dumbbell hammer curl': 'Rosca Martelo com Halteres',
    'barbell lying triceps extension': 'Tríceps Testa com Barra',
    'barbell bench squat': 'Agachamento Livre com Barra',
    'barbell straight leg deadlift': 'Stiff com Barra',
    '3-4 sit-up': 'Abdominal Supra no Solo',
  };

  let totalSeeded = 0;

  for (const mFolder of muscleFolders) {
    try {
      const res = await fetch(`${cdnBaseUrl}/api/en/muscles/${mFolder}.json`);
      if (res.ok) {
        const data = await res.json();
        if (data && Array.isArray(data.exercises)) {
          for (const item of data.exercises) {
            const cleanEn = item.name.trim();
            const lowerEn = cleanEn.toLowerCase();
            const namePt = namePtMap[lowerEn] || cleanEn
              .replace(/\bBarbell\b/gi, 'com Barra')
              .replace(/\bDumbbell\b/gi, 'com Halteres')
              .replace(/\bCable\b/gi, 'no Cabo')
              .replace(/\bBand\b/gi, 'com Elástico')
              .replace(/\bBench Press\b/gi, 'Supino')
              .replace(/\bSquat\b/gi, 'Agachamento')
              .replace(/\bDeadlift\b/gi, 'Levantamento Terra')
              .replace(/\bCurl\b/gi, 'Rosca')
              .replace(/\bPushdown\b/gi, 'Extensão')
              .replace(/\bPulldown\b/gi, 'Puxada')
              .replace(/\bCrunch\b/gi, 'Abdominal');

            const fullName = `${namePt} (${cleanEn})`;
            const mGroup = muscleGroupMap[mFolder] || 'OUTROS';
            const gifUrl = `${cdnBaseUrl}/${item.file}`;
            const rawInst = Array.isArray(item.instructions) && item.instructions.length > 0
              ? item.instructions
              : [`Execução correta de ${namePt}. Mantenha a postura e expire na fase concêntrica.`];
            const instructionsText = translateInstructions(rawInst);
            const secondaryStr = Array.isArray(item.secondaryMuscles) ? item.secondaryMuscles.join(', ') : item.secondaryMuscles || null;

            const existing = await prisma.exercise.findFirst({
              where: {
                OR: [
                  { namePt },
                  { nameEn: cleanEn },
                ],
              },
            });

            if (!existing) {
              await prisma.exercise.create({
                data: {
                  name: fullName,
                  namePt,
                  nameEn: cleanEn,
                  muscleGroup: mGroup,
                  secondaryMuscle: secondaryStr,
                  equipment: item.equipment || 'Outro',
                  metValue: 5.0,
                  gifUrl,
                  instructions: instructionsText,
                },
              });
            } else {
              await prisma.exercise.update({
                where: { id: existing.id },
                data: {
                  name: fullName,
                  namePt,
                  nameEn: cleanEn,
                  muscleGroup: mGroup,
                  gifUrl,
                  instructions: instructionsText,
                },
              });
            }
            totalSeeded++;
          }
        }
      }
    } catch (e) {
      console.warn(`Erro ao carregar muscle folder ${mFolder}:`, e);
    }
  }

  console.log(`Finalizado seed de ${totalSeeded} exercícios 3D!`);

  console.log('Seeding BodyIndicatorReference clinical standards...');
  const refCount = await prisma.bodyIndicatorReference.count();
  if (refCount === 0) {
    await prisma.bodyIndicatorReference.createMany({
      data: [
        { indicator: 'BODY_FAT_PERCENT', sex: 'MASCULINO', ageMin: 18, ageMax: 39, optimalMin: 8.0, optimalMax: 19.9, attentionMin: 20.0, attentionMax: 24.9, criticalMin: 0.0, criticalMax: 7.9, source: 'ACSM / OMS' },
        { indicator: 'BODY_FAT_PERCENT', sex: 'MASCULINO', ageMin: 40, ageMax: 59, optimalMin: 11.0, optimalMax: 21.9, attentionMin: 22.0, attentionMax: 27.9, criticalMin: 0.0, criticalMax: 10.9, source: 'ACSM / OMS' },
        { indicator: 'BODY_FAT_PERCENT', sex: 'MASCULINO', ageMin: 60, ageMax: 120, optimalMin: 13.0, optimalMax: 24.9, attentionMin: 25.0, attentionMax: 29.9, criticalMin: 0.0, criticalMax: 12.9, source: 'ACSM / OMS' },
        { indicator: 'BODY_FAT_PERCENT', sex: 'FEMININO', ageMin: 18, ageMax: 39, optimalMin: 15.0, optimalMax: 27.9, attentionMin: 28.0, attentionMax: 32.9, criticalMin: 0.0, criticalMax: 14.9, source: 'ACSM / OMS' },
        { indicator: 'BODY_FAT_PERCENT', sex: 'FEMININO', ageMin: 40, ageMax: 59, optimalMin: 18.0, optimalMax: 30.9, attentionMin: 31.0, attentionMax: 35.9, criticalMin: 0.0, criticalMax: 17.9, source: 'ACSM / OMS' },
        { indicator: 'BODY_FAT_PERCENT', sex: 'FEMININO', ageMin: 60, ageMax: 120, optimalMin: 20.0, optimalMax: 32.9, attentionMin: 33.0, attentionMax: 37.9, criticalMin: 0.0, criticalMax: 19.9, source: 'ACSM / OMS' },
        { indicator: 'BMI', sex: 'MASCULINO', ageMin: 18, ageMax: 120, optimalMin: 18.5, optimalMax: 24.9, attentionMin: 25.0, attentionMax: 29.9, criticalMin: 0.0, criticalMax: 18.4, source: 'OMS' },
        { indicator: 'BMI', sex: 'FEMININO', ageMin: 18, ageMax: 120, optimalMin: 18.5, optimalMax: 24.9, attentionMin: 25.0, attentionMax: 29.9, criticalMin: 0.0, criticalMax: 18.4, source: 'OMS' },
        { indicator: 'WAIST_HEIGHT_RATIO', sex: 'MASCULINO', ageMin: 1, ageMax: 120, optimalMin: 0.40, optimalMax: 0.49, attentionMin: 0.50, attentionMax: 0.59, criticalMin: 0.0, criticalMax: 0.39, source: 'Ashwell et al.' },
        { indicator: 'WAIST_HEIGHT_RATIO', sex: 'FEMININO', ageMin: 1, ageMax: 120, optimalMin: 0.40, optimalMax: 0.49, attentionMin: 0.50, attentionMax: 0.59, criticalMin: 0.0, criticalMax: 0.39, source: 'Ashwell et al.' },
        { indicator: 'PHASE_ANGLE', sex: 'MASCULINO', ageMin: 18, ageMax: 120, optimalMin: 6.5, optimalMax: 9.5, attentionMin: 5.5, attentionMax: 6.4, criticalMin: 0.0, criticalMax: 5.4, source: 'Norman et al. (2012)' },
        { indicator: 'PHASE_ANGLE', sex: 'FEMININO', ageMin: 18, ageMax: 120, optimalMin: 5.5, optimalMax: 8.5, attentionMin: 4.5, attentionMax: 5.4, criticalMin: 0.0, criticalMax: 4.4, source: 'Norman et al. (2012)' },
      ],
    });
    console.log('Clinical indicator references seeded successfully!');
  }

  console.log('Seeding completed successfully!');
}

main()
  .catch((e) => {
    console.error(e);
    process.exit(1);
  })
  .finally(async () => {
    await prisma.$disconnect();
  });

