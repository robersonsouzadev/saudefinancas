import {
  Injectable,
  Logger,
  NotFoundException,
  BadRequestException,
  ConflictException,
  ServiceUnavailableException,
} from '@nestjs/common';
import { ConfigService } from '@nestjs/config';
import * as fs from 'fs';
import * as path from 'path';
import * as crypto from 'crypto';
import { IPrivateObjectStorage, StoredObjectRef } from '../interfaces/storage.interface';
import { LinuxStorageHelper } from './storage-linux-helper';

@Injectable()
export class PrivateObjectStorageService implements IPrivateObjectStorage {
  private readonly logger = new Logger(PrivateObjectStorageService.name);
  private readonly basePath: string;
  private testBarrier?: (point: string, meta?: any) => Promise<void> | void;

  constructor(private readonly configService: ConfigService) {
    const customPath = this.configService.get<string>('STORAGE_PATH');
    const rawPath = customPath
      ? path.resolve(customPath)
      : path.resolve(process.cwd(), 'storage', 'private', 'wearables');

    if (!fs.existsSync(rawPath)) {
      fs.mkdirSync(rawPath, { recursive: true, mode: 0o700 });
    }

    try {
      this.basePath = fs.realpathSync(rawPath);
    } catch {
      this.basePath = rawPath;
    }
  }

  getBasePath(): string {
    return this.basePath;
  }

  setTestBarrier(barrier?: (point: string, meta?: any) => Promise<void> | void): void {
    this.testBarrier = barrier;
  }

  private validateAndResolveKey(key: string): { fullPath: string; dirPath: string; sanitizedKey: string } {
    if (!key || typeof key !== 'string') {
      throw new BadRequestException('Chave de storage inválida.');
    }

    // 1. Rejeição de bytes nulos e caracteres proibidos
    if (key.includes('\0')) {
      throw new BadRequestException('Chave contém bytes nulos inválidos.');
    }

    // 2. Rejeição explícita de caminhos absolutos forasteiros e ..
    if (path.isAbsolute(key) || key.includes('..')) {
      throw new BadRequestException('Chave contém sequências de navegação ou caminho absoluto proibido.');
    }

    const sanitizedKey = path.normalize(key).replace(/^(\.\.(\/|\\|$))+/, '');
    const fullPath = path.resolve(this.basePath, sanitizedKey);

    // 3. Validação de contenção estrita dentro de basePath
    if (!fullPath.startsWith(this.basePath + path.sep)) {
      throw new BadRequestException('Tentativa de path traversal detectada: caminho fora da raiz autorizada.');
    }

    const dirPath = path.dirname(fullPath);
    return { fullPath, dirPath, sanitizedKey };
  }

  private validateNoSymlinksInPath(targetPath: string): void {
    let current = path.resolve(targetPath);
    const root = this.basePath;

    while (current.length >= root.length) {
      if (fs.existsSync(current)) {
        const stat = fs.lstatSync(current);
        if (stat.isSymbolicLink()) {
          throw new BadRequestException(`Symlinks proibidos no storage: symlink detectado na árvore de diretórios (${current})`);
        }
        try {
          const real = fs.realpathSync(current);
          if (!real.startsWith(root + path.sep) && real !== root) {
            throw new BadRequestException(`Symlinks proibidos no storage: caminho canônico fora da raiz autorizada (${real})`);
          }
        } catch (err) {
          if (err instanceof BadRequestException) {
            throw err;
          }
          throw new BadRequestException(`Symlinks proibidos no storage: falha ao resolver caminho canônico intermediário (${current})`);
        }
      }
      if (current === root) break;
      const parent = path.dirname(current);
      if (parent === current) break;
      current = parent;
    }
  }

  async putObject(key: string, buffer: Buffer, expectedSha256?: string): Promise<StoredObjectRef> {
    const { fullPath, dirPath, sanitizedKey } = this.validateAndResolveKey(key);

    try {
      this.validateNoSymlinksInPath(dirPath);

      // Verificação preliminar do destino com lstat (detecta symlinks quebrados ou existentes)
      const preStat = fs.lstatSync(fullPath, { throwIfNoEntry: false });
      if (preStat) {
        if (preStat.isSymbolicLink()) {
          throw new BadRequestException(`Symlinks proibidos no storage: destino é um symlink (${fullPath})`);
        }
        throw new ConflictException(`Conflito de storage: arquivo já existe em destino (${sanitizedKey}). Sobrescrita proibida.`);
      }

      if (!fs.existsSync(dirPath)) {
        fs.mkdirSync(dirPath, { recursive: true, mode: 0o700 });
      }

      // Validação de integridade do payload antes da escrita
      const calculatedSha256 = crypto.createHash('sha256').update(buffer).digest('hex');
      if (expectedSha256 && calculatedSha256 !== expectedSha256) {
        throw new BadRequestException('SHA-256 do buffer não corresponde ao hash esperado antes da gravação.');
      }

      // Escrita segura em diretório temporário restrito à raiz autorizada do storage
      const tmpUploadsDir = path.join(this.basePath, '.tmp_uploads');
      if (!fs.existsSync(tmpUploadsDir)) {
        fs.mkdirSync(tmpUploadsDir, { recursive: true, mode: 0o700 });
      }

      const tempFileName = `.tmp_${crypto.randomBytes(16).toString('hex')}`;
      const tempPath = path.join(tmpUploadsDir, tempFileName);

      const openFlags =
        fs.constants.O_CREAT |
        fs.constants.O_EXCL |
        fs.constants.O_WRONLY |
        (fs.constants.O_NOFOLLOW || 0);

      // Gravação em arquivo temporário com permissões estritas 0600
      const fileHandle = await fs.promises.open(tempPath, openFlags, 0o600);
      await fileHandle.writeFile(buffer);
      await fileHandle.sync(); // fsync do arquivo temporário
      await fileHandle.close();

      // Ponto de sincronização determinístico para testes (Anti-TOCTOU barrier)
      if (this.testBarrier) {
        await this.testBarrier('pre-publish', { key: sanitizedKey, dirPath, fullPath, tempPath });
      }

      // 1. VIA HELPER LINUX BASEADO EM DESCRITORES (openat2, RESOLVE_BENEATH, linkat, unlinkat)
      if (LinuxStorageHelper.isLinuxDescriptorHelperAvailable()) {
        const tempRel = path.relative(this.basePath, tempPath).replace(/\\/g, '/');
        const targetRel = sanitizedKey.replace(/\\/g, '/');
        const helperRes = LinuxStorageHelper.write(this.basePath, targetRel, tempRel);
        await fs.promises.unlink(tempPath).catch(() => {});

        if (!helperRes.success) {
          if (helperRes.exitCode === 2 || helperRes.stderr?.includes('[EEXIST]')) {
            throw new ConflictException(`Conflito de storage: arquivo já existe em destino (${sanitizedKey}). Sobrescrita proibida.`);
          }
          if (helperRes.stderr?.includes('SECURITY_') || helperRes.stderr?.includes('symlink')) {
            throw new BadRequestException(`Symlinks proibidos no storage: ${helperRes.stderr.trim()}`);
          }
          throw new BadRequestException(`Falha de segurança no storage via descritores: ${helperRes.stderr || 'erro descritor'}`);
        }

        return {
          storageKey: sanitizedKey.replace(/\\/g, '/'),
          storageDriver: 'LOCAL_SECURE',
          fileSizeBytes: buffer.length,
        };
      }

      // 2. FALLBACK PORTÁTIL DE DESCRITORES (DESENVOLVIMENTO LOCAL / TESTES)
      const dirOpenFlags = fs.constants.O_RDONLY | (fs.constants.O_DIRECTORY || 0) | (fs.constants.O_NOFOLLOW || 0);
      let dirHandle: fs.promises.FileHandle | null = null;

      try {
        dirHandle = await fs.promises.open(dirPath, dirOpenFlags);
        if (fs.existsSync(`/proc/self/fd/${dirHandle.fd}`)) {
          const canonicalDirPath = fs.realpathSync(`/proc/self/fd/${dirHandle.fd}`);
          if (!canonicalDirPath.startsWith(this.basePath + path.sep) && canonicalDirPath !== this.basePath) {
            throw new BadRequestException('Symlinks proibidos no storage: escape de diretório detectado via descritor.');
          }
        }

        // Re-validação anti-TOCTOU mantendo o descritor de diretório aberto
        this.validateNoSymlinksInPath(dirPath);
        if (fs.existsSync(fullPath)) {
          const postBarrierStat = fs.lstatSync(fullPath);
          if (postBarrierStat.isSymbolicLink()) {
            throw new BadRequestException('Symlinks proibidos no storage: symlink detectado no caminho alvo pós-barreira.');
          }
        }

        // Publicação atômica NO-CLOBBER via fs.promises.link
        await fs.promises.link(tempPath, fullPath);

        // Verificação pós-publicação do arquivo final aberto via O_NOFOLLOW
        const checkOpenFlags = fs.constants.O_RDONLY | (fs.constants.O_NOFOLLOW || 0);
        let checkHandle: fs.promises.FileHandle | null = null;
        try {
          checkHandle = await fs.promises.open(fullPath, checkOpenFlags);
          if (fs.existsSync(`/proc/self/fd/${checkHandle.fd}`)) {
            const canonicalPublished = fs.realpathSync(`/proc/self/fd/${checkHandle.fd}`);
            if (!canonicalPublished.startsWith(this.basePath + path.sep)) {
              await fs.promises.unlink(fullPath).catch(() => {});
              throw new BadRequestException('Symlinks proibidos no storage: escape pós-publicação detectado.');
            }
          }
          const canonicalOnDisk = fs.realpathSync(fullPath);
          if (!canonicalOnDisk.startsWith(this.basePath + path.sep)) {
            await fs.promises.unlink(fullPath).catch(() => {});
            throw new BadRequestException('Symlinks proibidos no storage: escape pós-publicação detectado.');
          }
        } finally {
          if (checkHandle) {
            await checkHandle.close().catch(() => {});
          }
        }

        // fsync do diretório pai para durabilidade dos metadados com descritor aberto
        await dirHandle.sync().catch(() => {});
      } catch (linkErr: any) {
        if (linkErr.code === 'EEXIST') {
          const checkStat = fs.lstatSync(fullPath, { throwIfNoEntry: false });
          if (checkStat && checkStat.isSymbolicLink()) {
            throw new BadRequestException(`Symlinks proibidos no storage: tentativa de sobrescrita de symlink.`);
          }
          throw new ConflictException(`Conflito de storage: arquivo já existe em destino (${sanitizedKey}). Sobrescrita proibida.`);
        }
        throw linkErr;
      } finally {
        if (dirHandle) {
          await dirHandle.close().catch(() => {});
        }
        await fs.promises.unlink(tempPath).catch(() => {});
      }

      return {
        storageKey: sanitizedKey.replace(/\\/g, '/'),
        storageDriver: 'LOCAL_SECURE',
        fileSizeBytes: buffer.length,
      };
    } catch (err: any) {
      if (err instanceof BadRequestException || err instanceof ConflictException) {
        throw err;
      }
      if (err.code === 'EACCES' || err.code === 'EROFS' || err.code === 'ENOSPC') {
        this.logger.error(`Falha crítica de volume no storage: ${err.code} - ${err.message}`);
        throw new ServiceUnavailableException(`Storage LOCAL_SECURE indisponível ou somente leitura: ${err.code}`);
      }
      throw err;
    }
  }

  async getObject(key: string, expectedSha256?: string): Promise<Buffer> {
    const { fullPath, dirPath, sanitizedKey } = this.validateAndResolveKey(key);

    try {
      if (!fs.existsSync(fullPath)) {
        throw new NotFoundException(`Objeto de storage não encontrado: ${key}`);
      }

      // Ponto de sincronização determinístico para testes de leitura
      if (this.testBarrier) {
        await this.testBarrier('pre-read', { key: sanitizedKey, dirPath, fullPath });
      }

      // 1. VIA HELPER LINUX BASEADO EM DESCRITORES
      if (LinuxStorageHelper.isLinuxDescriptorHelperAvailable()) {
        const targetRel = sanitizedKey.replace(/\\/g, '/');
        const helperRes = LinuxStorageHelper.read(this.basePath, targetRel);
        if (!helperRes.success) {
          if (helperRes.stderr?.includes('SECURITY_') || helperRes.stderr?.includes('symlink')) {
            throw new BadRequestException(`Symlinks proibidos no storage: ${helperRes.stderr.trim()}`);
          }
          throw new NotFoundException(`Objeto de storage não encontrado: ${key}`);
        }
        const buffer = helperRes.stdout || Buffer.alloc(0);
        if (expectedSha256) {
          const readSha256 = crypto.createHash('sha256').update(buffer).digest('hex');
          if (readSha256 !== expectedSha256) {
            throw new BadRequestException(`Violação de integridade no storage: SHA-256 lido difere do esperado.`);
          }
        }
        return buffer;
      }

      // 2. FALLBACK PORTÁTIL DE DESCRITORES
      this.validateNoSymlinksInPath(fullPath);
      const preStat = fs.lstatSync(fullPath);
      if (preStat.isSymbolicLink()) {
        throw new BadRequestException('Symlinks proibidos no storage: symlink detectado na leitura.');
      }

      const openFlags = fs.constants.O_RDONLY | (fs.constants.O_NOFOLLOW || 0);
      let fileHandle: fs.promises.FileHandle | null = null;
      try {
        fileHandle = await fs.promises.open(fullPath, openFlags);

        if (fs.existsSync(`/proc/self/fd/${fileHandle.fd}`)) {
          const canonicalFdPath = fs.realpathSync(`/proc/self/fd/${fileHandle.fd}`);
          if (!canonicalFdPath.startsWith(this.basePath + path.sep)) {
            throw new BadRequestException('Symlinks proibidos no storage: escape de diretório intermediário detectado via descritor.');
          }
        }

        const canonicalFile = fs.realpathSync(fullPath);
        if (!canonicalFile.startsWith(this.basePath + path.sep)) {
          throw new BadRequestException('Symlinks proibidos no storage: escape de diretório intermediário detectado.');
        }

        const stat = await fileHandle.stat();
        if (!stat.isFile()) {
          throw new BadRequestException('Recurso no storage não é um arquivo regular.');
        }

        const buffer = await fileHandle.readFile();

        if (expectedSha256) {
          const readSha256 = crypto.createHash('sha256').update(buffer).digest('hex');
          if (readSha256 !== expectedSha256) {
            throw new BadRequestException(`Violação de integridade no storage: SHA-256 lido (${readSha256}) difere do esperado (${expectedSha256}).`);
          }
        }

        return buffer;
      } finally {
        if (fileHandle) {
          await fileHandle.close().catch(() => {});
        }
      }
    } catch (err: any) {
      if (err instanceof NotFoundException || err instanceof BadRequestException) {
        throw err;
      }
      if (err.code === 'ELOOP' || err.code === 'EINVAL') {
        throw new BadRequestException('Symlinks proibidos no storage.');
      }
      if (err.code === 'EACCES' || err.code === 'EROFS') {
        this.logger.error(`Falha crítica de leitura no storage: ${err.code} - ${err.message}`);
        throw new ServiceUnavailableException(`Storage LOCAL_SECURE inacessível para leitura: ${err.code}`);
      }
      throw err;
    }
  }

  async deleteObject(key: string): Promise<void> {
    const { fullPath, sanitizedKey } = this.validateAndResolveKey(key);

    if (fs.existsSync(fullPath)) {
      if (this.testBarrier) {
        await this.testBarrier('pre-delete', { key, fullPath });
      }

      // 1. VIA HELPER LINUX BASEADO EM DESCRITORES
      if (LinuxStorageHelper.isLinuxDescriptorHelperAvailable()) {
        const targetRel = sanitizedKey.replace(/\\/g, '/');
        const helperRes = LinuxStorageHelper.unlink(this.basePath, targetRel);
        if (!helperRes.success) {
          if (helperRes.stderr?.includes('SECURITY_') || helperRes.stderr?.includes('symlink')) {
            throw new BadRequestException('Tentativa de remoção de symlink proibido no storage.');
          }
          throw new Error(`Falha ao remover arquivo do storage: ${helperRes.stderr}`);
        }
        return;
      }

      // 2. FALLBACK PORTÁTIL DE DESCRITORES
      this.validateNoSymlinksInPath(fullPath);
      const lstat = await fs.promises.lstat(fullPath);
      if (lstat.isSymbolicLink()) {
        throw new BadRequestException('Tentativa de remoção de symlink proibido no storage.');
      }
      try {
        await fs.promises.unlink(fullPath);
      } catch (unlinkErr: any) {
        if (unlinkErr.code !== 'ENOENT') {
          this.logger.error(`Falha ao remover arquivo do storage: ${key}. Erro: ${unlinkErr?.message}`);
          throw unlinkErr;
        }
      }
    }
  }

  async reconcileOrphans(knownKeys: Set<string>, gracePeriodMs: number = 60 * 60 * 1000): Promise<string[]> {
    const orphans: string[] = [];
    const cutoffTime = Date.now() - gracePeriodMs;

    const walk = (dir: string) => {
      if (!fs.existsSync(dir)) return;
      const entries = fs.readdirSync(dir, { withFileTypes: true });
      for (const entry of entries) {
        if (entry.name === '.tmp_uploads') continue;
        const res = path.resolve(dir, entry.name);
        if (entry.isDirectory()) {
          walk(res);
        } else {
          // Ignora arquivos temporários de escrita em andamento
          if (entry.name.startsWith('.tmp_')) continue;

          const relKey = path.relative(this.basePath, res).replace(/\\/g, '/');
          if (!knownKeys.has(relKey)) {
            // PROTEÇÃO ANTI-TOCTOU: só considerar órfão se mtime > grace period (default 1 hora)
            try {
              const stat = fs.statSync(res);
              if (stat.mtimeMs < cutoffTime) {
                orphans.push(relKey);
              } else {
                this.logger.debug(
                  `[Orphan Check] Arquivo ${relKey} ausente no banco mas recente (age=${Math.round((Date.now() - stat.mtimeMs) / 1000)}s). Preservado pelo grace period.`,
                );
              }
            } catch {
              // Se stat falhar, ignorar silenciosamente
            }
          }
        }
      }
    };

    walk(this.basePath);
    return orphans;
  }

  async isHealthy(): Promise<boolean> {
    try {
      await fs.promises.access(this.basePath, fs.constants.R_OK | fs.constants.W_OK);
      const stat = await fs.promises.stat(this.basePath);
      return stat.isDirectory();
    } catch {
      return false;
    }
  }
}

